<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreStoreRequest;
use App\Http\Requests\UpdateStoreRequest;
use App\Models\Store;
use GuzzleHttp\Client;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;

class StoreController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Inertia\Response
     */
    public function index(): \Inertia\Response
    {
//        return Inertia::render('Stores', [
//            'stores' => Auth::user()->stores
//        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return RedirectResponse
     */
    public function create(): RedirectResponse
    {
        return redirect(sprintf('https://oauth.aliexpress.com/authorize?response_type=code&client_id=%s&state=%s&view=web&sp=ae',
            env('AE_APP_KEY'), Auth::id()));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreStoreRequest $request
     * @return RedirectResponse
     */
    public function store(StoreStoreRequest $request): RedirectResponse
    {
        $code = $request->get('code');
        $userId = $request->get('state');
        if ($userId != Auth::id()) {
            abort(403, 'You didnt made this request');
        }
        $c = new Client();
        $response = $c->post('https://oauth.aliexpress.com/token', ['form_params' => [
            'grant_type' => 'authorization_code',
            'client_id' => env('AE_APP_KEY'),
            'client_secret' => env('AE_APP_SECRET'),
            'code' => $code,
            'sp' => 'ae',
            'redirect_uri' => 'https://wizard.ihsanerdem.com/callback'
        ]]);

        $data = json_decode($response->getBody()->getContents(), true);
        if (array_key_exists('error_msg', $data) || !array_key_exists('access_token', $data)) {
            abort(403, $data['error_msg'] . ' | ' . $data['error_code']);
        }

        $mProfile = getMerchantProfile($data['access_token']);
        $storeQuery = Store::where('store_id', $mProfile->shop_id)->where('user_id', Auth::id())->get();

        if (count($storeQuery) == 0) {
            //we dont have the store, create it
            $store = Store::create([
                'store_name' => $mProfile->shop_name,
                'store_id' => $mProfile->shop_id,
                'store_url' => $mProfile->shop_url,
                'access_token' => $data['access_token'],
                'user_id' => Auth::id()
            ]);

        } else {
            //we have the store update access token
            $store = $storeQuery[0];
//            $store->store_name = $store->store_name . ' 2 ';
            $store->access_token = $data['access_token'];
            $store->save();
        }
        return redirect(route('app'))->intended('');
    }

    /**
     * Display the specified resource.
     *
     * @param Store $store
     * @return Response
     */
    public function show(Store $store)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Store $store
     * @return Response
     */
    public function edit(Store $store)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateStoreRequest $request
     * @param Store $store
     * @return Response
     */
    public function update(UpdateStoreRequest $request, Store $store)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Store $store
     * @return Response
     */
    public function destroy(Store $store)
    {
        //
    }
}


1,使用方式，参见SecurityTest.php

2,建议使用本地缓存解密秘钥，可以使用系统实现的 YacCache 或者自己去实现 iCache 接口插入到 SecurityClient 中。

3，(必须安装) 加密框架依赖 mcrypt 扩展，安装参见 http://www.cnblogs.com/lihanbingboke/p/5534258.html

4，(可选安装) YacCache 依赖 yac 扩展，安装参见 http://www.widuu.com/archives/09/792.html

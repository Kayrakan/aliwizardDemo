<?php
/**
 * TOP API: aliexpress.freight.redefining.listfreighttemplate request
 * 
 * @author auto create
 * @since 1.0, 2018.07.25
 */
class AliexpressFreightRedefiningListfreighttemplateRequest
{
	
	private $apiParas = array();
	
	public function getApiMethodName()
	{
		return "aliexpress.freight.redefining.listfreighttemplate";
	}
	
	public function getApiParas()
	{
		return $this->apiParas;
	}
	
	public function check()
	{
		
	}
	
	public function putOtherTextParam($key, $value) {
		$this->apiParas[$key] = $value;
		$this->$key = $value;
	}
}

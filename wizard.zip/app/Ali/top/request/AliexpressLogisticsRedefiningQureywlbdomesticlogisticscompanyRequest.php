<?php
/**
 * TOP API: aliexpress.logistics.redefining.qureywlbdomesticlogisticscompany request
 * 
 * @author auto create
 * @since 1.0, 2018.07.25
 */
class AliexpressLogisticsRedefiningQureywlbdomesticlogisticscompanyRequest
{
	
	private $apiParas = array();
	
	public function getApiMethodName()
	{
		return "aliexpress.logistics.redefining.qureywlbdomesticlogisticscompany";
	}
	
	public function getApiParas()
	{
		return $this->apiParas;
	}
	
	public function check()
	{
		
	}
	
	public function putOtherTextParam($key, $value) {
		$this->apiParas[$key] = $value;
		$this->$key = $value;
	}
}

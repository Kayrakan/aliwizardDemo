<?php

/**
 * 活动商品优惠信息
 * @author auto create
 */
class AeopProductDiscountInfo
{
	
	/** 
	 * 折扣
	 **/
	public $discount;
	
	/** 
	 * 终端 MOBILE or ALL
	 **/
	public $terminal;	
}
?>
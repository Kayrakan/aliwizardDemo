<?php

/**
 * result
 * @author auto create
 */
class AeopTaoDaiXiaoClaimResultDto
{
	
	/** 
	 * 认领失败时的错误码
	 **/
	public $error_code;
	
	/** 
	 * 认领失败时的错误信息
	 **/
	public $error_message;
	
	/** 
	 * 接口调用结果。true/false分别表示成功和失败。
	 **/
	public $success;	
}
?>
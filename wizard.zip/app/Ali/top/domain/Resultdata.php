<?php

/**
 * 明细条目执行结果对象
 * @author auto create
 */
class Resultdata
{
	
	/** 
	 * 1
	 **/
	public $error_desc;
	
	/** 
	 * 结果列表
	 **/
	public $result_list;
	
	/** 
	 * 明细条目执行结果的成功状态
	 **/
	public $success;	
}
?>
<?php

/**
 * 返回对象
 * @author auto create
 */
class AeopOnlineLogisticsServiceResponse
{
	
	/** 
	 * 错误描述
	 **/
	public $error_desc;
	
	/** 
	 * 是否成功
	 **/
	public $is_success;
	
	/** 
	 * result list
	 **/
	public $result_list;	
}
?>
<?php

/**
 * 国家列表
 * @author auto create
 */
class CountryList
{
	
	/** 
	 * code
	 **/
	public $code;
	
	/** 
	 * name
	 **/
	public $name;	
}
?>
<?php

/**
 * 入参如下
 * @author auto create
 */
class AeopOrderCancelRequest
{
	
	/** 
	 * 买家登录帐号
	 **/
	public $buyer_login_id;
	
	/** 
	 * 订单id
	 **/
	public $order_id;	
}
?>
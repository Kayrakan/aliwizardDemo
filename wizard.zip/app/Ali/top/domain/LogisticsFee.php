<?php

/**
 * 运费
 * @author auto create
 */
class LogisticsFee
{
	
	/** 
	 * 金额分
	 **/
	public $cent;
	
	/** 
	 * 币种
	 **/
	public $currency_code;	
}
?>
<?php

/**
 * 入参
 * @author auto create
 */
class PromotionProductQueryDto
{
	
	/** 
	 * 页码,从1开始
	 **/
	public $page_no;
	
	/** 
	 * 页大小
	 **/
	public $page_size;
	
	/** 
	 * 活动ID
	 **/
	public $promotion_id;	
}
?>
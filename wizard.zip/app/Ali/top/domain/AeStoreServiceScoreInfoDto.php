<?php

/**
 * 返回结果
 * @author auto create
 */
class AeStoreServiceScoreInfoDto
{
	
	/** 
	 * 主赚二级类目id
	 **/
	public $prim_opr_pcate_lv2_id;
	
	/** 
	 * 主赚二级类目名称
	 **/
	public $prim_opr_pcate_lv2_name;
	
	/** 
	 * 服务分具体信息
	 **/
	public $service_score_info_d_t_o;	
}
?>
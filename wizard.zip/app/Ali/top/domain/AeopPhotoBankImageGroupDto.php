<?php

/**
 * 图片银行分组列表，如果没有任何的分组信息。这个属性为:[]。
 * @author auto create
 */
class AeopPhotoBankImageGroupDto
{
	
	/** 
	 * 图片分组ID
	 **/
	public $group_id;
	
	/** 
	 * 图片分组名称
	 **/
	public $group_name;	
}
?>
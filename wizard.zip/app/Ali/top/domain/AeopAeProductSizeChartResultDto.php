<?php

/**
 * result
 * @author auto create
 */
class AeopAeProductSizeChartResultDto
{
	
	/** 
	 * 错误代码
	 **/
	public $error_code;
	
	/** 
	 * 系统异常信息
	 **/
	public $error_message;
	
	/** 
	 * 错误信息
	 **/
	public $error_msg;
	
	/** 
	 * 尺码标模版列表
	 **/
	public $sizechart_d_t_o_list;
	
	/** 
	 * 调用方法成功标识，true/false分别代表成功和失败
	 **/
	public $success;	
}
?>
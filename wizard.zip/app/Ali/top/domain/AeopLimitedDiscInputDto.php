<?php

/**
 * 输入参数
 * @author auto create
 */
class AeopLimitedDiscInputDto
{
	
	/** 
	 * 活动结束时间
	 **/
	public $promotion_end_time;
	
	/** 
	 * 活动id
	 **/
	public $promotion_id;
	
	/** 
	 * 活动名称
	 **/
	public $promotion_name;
	
	/** 
	 * 活动开始时间
	 **/
	public $promotion_start_time;	
}
?>
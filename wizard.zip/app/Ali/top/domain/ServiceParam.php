<?php

/**
 * 服务参数
 * @author auto create
 */
class ServiceParam
{
	
	/** 
	 * DOOR_PICKUP：揽收仓资源、SELF_SEND：自送dropOff
	 **/
	public $code;	
}
?>
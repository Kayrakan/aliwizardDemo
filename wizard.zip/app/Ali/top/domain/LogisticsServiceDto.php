<?php

/**
 * 物流服务列表
 * @author auto create
 */
class LogisticsServiceDto
{
	
	/** 
	 * 物流服务编码
	 **/
	public $code;
	
	/** 
	 * 资源编码
	 **/
	public $resource_code;	
}
?>
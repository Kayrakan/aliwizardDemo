<?php

/**
 * 发件信息
 * @author auto create
 */
class OpenSenderParam
{
	
	/** 
	 * 商家后台维护的揽收地址ID
	 **/
	public $seller_address_id;	
}
?>
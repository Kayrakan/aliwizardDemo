<?php

/**
 * 其它费用项
 * @author auto create
 */
class Otherfees
{
	
	/** 
	 * amount
	 **/
	public $amount;
	
	/** 
	 * 费用项code
	 **/
	public $code;
	
	/** 
	 * curreny
	 **/
	public $curreny;
	
	/** 
	 * 费用名称
	 **/
	public $name;	
}
?>
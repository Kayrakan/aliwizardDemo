<?php

/**
 * result
 * @author auto create
 */
class AeopRelateSizeChartResponse
{
	
	/** 
	 * 错误代码
	 **/
	public $error_code;
	
	/** 
	 * 错误信息
	 **/
	public $error_message;
	
	/** 
	 * 设置结果。true/false分别表示成功和失败。
	 **/
	public $is_success;
	
	/** 
	 * 商品ID
	 **/
	public $product_id;
	
	/** 
	 * 尺码表模版Id
	 **/
	public $sizechart_id;	
}
?>
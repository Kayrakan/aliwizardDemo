<?php

/**
 * data
 * @author auto create
 */
class Data
{
	
	/** 
	 * content
	 **/
	public $content;
	
	/** 
	 * remarkId
	 **/
	public $remark_id;	
}
?>
<?php

/**
 * update successful list
 * @author auto create
 */
class SynchronizeProductResponseDto
{
	
	/** 
	 * product id
	 **/
	public $product_id;	
}
?>
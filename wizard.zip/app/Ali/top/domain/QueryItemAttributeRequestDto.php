<?php

/**
 * 查询商品物流属性入参
 * @author auto create
 */
class QueryItemAttributeRequestDto
{
	
	/** 
	 * 商品id
	 **/
	public $item_id;
	
	/** 
	 * 店铺id
	 **/
	public $store_id;	
}
?>
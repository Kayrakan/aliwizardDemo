<?php

/**
 * 请求结果
 * @author auto create
 */
class GlspResponse
{
	
	/** 
	 * 错误信息
	 **/
	public $error_info;
	
	/** 
	 * 查询是否成功
	 **/
	public $is_success;
	
	/** 
	 * 请求结果
	 **/
	public $result;	
}
?>
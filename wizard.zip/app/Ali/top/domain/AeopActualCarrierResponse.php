<?php

/**
 * 返回数据
 * @author auto create
 */
class AeopActualCarrierResponse
{
	
	/** 
	 * 实际承运商
	 **/
	public $courier_list;	
}
?>
<?php

/**
 * multo language description list
 * @author auto create
 */
class GlobalDescription
{
	
	/** 
	 * locale of the descripiton
	 **/
	public $locale;
	
	/** 
	 * mobile detail
	 **/
	public $mobile_detail;
	
	/** 
	 * web detail
	 **/
	public $web_detail;	
}
?>
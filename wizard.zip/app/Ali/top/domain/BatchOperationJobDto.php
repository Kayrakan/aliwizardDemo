<?php

/**
 * data
 * @author auto create
 */
class BatchOperationJobDto
{
	
	/** 
	 * job id
	 **/
	public $job_id;
	
	/** 
	 * feed type
	 **/
	public $operation_type;
	
	/** 
	 * The status of the feed
	 **/
	public $status;	
}
?>
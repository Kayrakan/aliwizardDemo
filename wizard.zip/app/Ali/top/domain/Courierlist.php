<?php

/**
 * 实际承运商
 * @author auto create
 */
class Courierlist
{
	
	/** 
	 * 承运商code
	 **/
	public $courier_code;
	
	/** 
	 * 承运商名字
	 **/
	public $courier_name;	
}
?>
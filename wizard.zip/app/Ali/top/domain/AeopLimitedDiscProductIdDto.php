<?php

/**
 * 系统自动生成
 * @author auto create
 */
class AeopLimitedDiscProductIdDto
{
	
	/** 
	 * 要删除的商品id集合
	 **/
	public $product_id_list;
	
	/** 
	 * 活动id
	 **/
	public $promotion_id;	
}
?>
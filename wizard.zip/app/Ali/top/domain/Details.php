<?php

/**
 * 追踪详细信息列表
 * @author auto create
 */
class Details
{
	
	/** 
	 * address
	 **/
	public $address;
	
	/** 
	 * eventDate
	 **/
	public $event_date;
	
	/** 
	 * eventDesc
	 **/
	public $event_desc;
	
	/** 
	 * signedName
	 **/
	public $signed_name;
	
	/** 
	 * status
	 **/
	public $status;	
}
?>
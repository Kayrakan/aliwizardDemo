<?php

/**
 * 请求结果
 * @author auto create
 */
class SolutionServiceResQueryResponse
{
	
	/** 
	 * 物流服务资源列表
	 **/
	public $solution_service_res_list;	
}
?>
<?php

/**
 * selfstandard
 * @author auto create
 */
class AeopFreightSelfdefineStandard
{
	
	/** 
	 * 自定义运费国家
	 **/
	public $self_standard_country;
	
	/** 
	 * 自定义标准折扣
	 **/
	public $self_standard_discount;	
}
?>
<?php

/**
 * 响应数据
 * @author auto create
 */
class CloudPrintDataGetResponse
{
	
	/** 
	 * 面单云打印数据
	 **/
	public $print_data;
	
	/** 
	 * 面单云打印数据MD5加密串
	 **/
	public $print_data_md5;	
}
?>
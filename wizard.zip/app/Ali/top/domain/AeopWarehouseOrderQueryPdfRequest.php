<?php

/**
 * 批量查询线上发货信息进去打印,列表类型，以json格式来表达
 * @author auto create
 */
class AeopWarehouseOrderQueryPdfRequest
{
	
	/** 
	 * 自定义分拣单信息
	 **/
	public $extend_data;
	
	/** 
	 * 物流订单号
	 **/
	public $id;
	
	/** 
	 * 创建线上发货  产生的 国际运单号
	 **/
	public $international_logistics_id;	
}
?>
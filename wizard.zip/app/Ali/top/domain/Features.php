<?php

/**
 * 扩展字段
 * @author auto create
 */
class Features
{
	
	/** 
	 * 预约流程
	 **/
	public $appointment_process;
	
	/** 
	 * 是否需要预约
	 **/
	public $need_appointment;
	
	/** 
	 * 揽收时间
	 **/
	public $pickup_work_time;	
}
?>
<?php

/**
 * 响应数据
 * @author auto create
 */
class OpenHandoverCancelResponse
{
	
	/** 
	 * 取消结果
	 **/
	public $result;	
}
?>
<?php

/**
 * 响应数据
 * @author auto create
 */
class OpenHandoverUpdateResponse
{
	
	/** 
	 * 更新结果
	 **/
	public $result;	
}
?>
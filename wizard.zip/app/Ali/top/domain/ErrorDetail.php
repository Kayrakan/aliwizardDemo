<?php

/**
 * 错误详情
 * @author auto create
 */
class ErrorDetail
{
	
	/** 
	 * 错误代码
	 **/
	public $error_code;
	
	/** 
	 * productIds
	 **/
	public $product_ids;	
}
?>
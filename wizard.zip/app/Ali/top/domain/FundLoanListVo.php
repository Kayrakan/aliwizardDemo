<?php

/**
 * 出参
 * @author auto create
 */
class FundLoanListVo
{
	
	/** 
	 * 订单放款列表
	 **/
	public $order_list;
	
	/** 
	 * 总条数
	 **/
	public $total_item;	
}
?>
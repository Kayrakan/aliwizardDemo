<?php

/**
 * 发布类目对象
 * @author auto create
 */
class AeopPostCategoryResponse
{
	
	/** 
	 * 发布类目
	 **/
	public $aeop_post_category_list;
	
	/** 
	 * 服务调用是否成功
	 **/
	public $success;	
}
?>
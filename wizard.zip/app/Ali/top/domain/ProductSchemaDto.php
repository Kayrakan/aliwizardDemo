<?php

/**
 * result
 * @author auto create
 */
class ProductSchemaDto
{
	
	/** 
	 * error code
	 **/
	public $error_code;
	
	/** 
	 * error message
	 **/
	public $error_message;
	
	/** 
	 * schema
	 **/
	public $schema;
	
	/** 
	 * success flag
	 **/
	public $success;	
}
?>
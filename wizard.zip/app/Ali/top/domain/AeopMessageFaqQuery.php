<?php

/**
 * 入参如下
 * @author auto create
 */
class AeopMessageFaqQuery
{
	
	/** 
	 * 问题id
	 **/
	public $faq_id;	
}
?>
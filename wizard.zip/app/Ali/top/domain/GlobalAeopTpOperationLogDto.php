<?php

/**
 * operation details list
 * @author auto create
 */
class GlobalAeopTpOperationLogDto
{
	
	/** 
	 * action type
	 **/
	public $action_type;
	
	/** 
	 * child order ID
	 **/
	public $child_order_id;
	
	/** 
	 * order creation time
	 **/
	public $gmt_create;
	
	/** 
	 * order modification time
	 **/
	public $gmt_modified;
	
	/** 
	 * id
	 **/
	public $id;
	
	/** 
	 * buyer memo
	 **/
	public $memo;
	
	/** 
	 * operator
	 **/
	public $operator;
	
	/** 
	 * order ID
	 **/
	public $order_id;	
}
?>
<?php

/**
 * aeopFreightCalculateResultDTOList
 * @author auto create
 */
class Aeopfreightcalculateresultdtolist
{
	
	/** 
	 * errorCode
	 **/
	public $error_code;
	
	/** 
	 * freight
	 **/
	public $freight;
	
	/** 
	 * serviceName
	 **/
	public $service_name;
	
	/** 
	 * standardFreight
	 **/
	public $standard_freight;	
}
?>
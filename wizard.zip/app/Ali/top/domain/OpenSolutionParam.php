<?php

/**
 * 解决方案参数
 * @author auto create
 */
class OpenSolutionParam
{
	
	/** 
	 * 物流服务列表
	 **/
	public $service_params;
	
	/** 
	 * 解决方案code
	 **/
	public $solution_code;	
}
?>
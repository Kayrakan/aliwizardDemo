<?php

/**
 * multi language subject list
 * @author auto create
 */
class GlobalSubject
{
	
	/** 
	 * locale of the subject
	 **/
	public $locale;
	
	/** 
	 * subject
	 **/
	public $subject;	
}
?>
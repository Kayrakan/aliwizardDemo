<?php

/**
 * 接口返回model
 * @author auto create
 */
class Result
{
	
	/** 
	 * 当前页
	 **/
	public $current_page;
	
	/** 
	 * 结果
	 **/
	public $result_list;
	
	/** 
	 * 是否成功
	 **/
	public $success;
	
	/** 
	 * totalPage
	 **/
	public $total_page;	
}
?>
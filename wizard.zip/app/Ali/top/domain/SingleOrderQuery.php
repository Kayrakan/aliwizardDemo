<?php

/**
 * query param
 * @author auto create
 */
class SingleOrderQuery
{
	
	/** 
	 * order ID
	 **/
	public $order_id;	
}
?>
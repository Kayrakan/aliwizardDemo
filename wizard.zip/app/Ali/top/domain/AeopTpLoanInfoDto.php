<?php

/**
 * 放款信息
 * @author auto create
 */
class AeopTpLoanInfoDto
{
	
	/** 
	 * 放款金额
	 **/
	public $loan_amount;
	
	/** 
	 * 放款时间（此时间为美国太平洋时间）
	 **/
	public $loan_time;	
}
?>
<?php

/**
 * aliexpress sku value list
 * @author auto create
 */
class SkuValueSimplifiedInfoDto
{
	
	/** 
	 * aliexpress sku value name
	 **/
	public $aliexpress_sku_value_name;	
}
?>
<?php

/**
 * 错误信息
 * @author auto create
 */
class ErrorInfo
{
	
	/** 
	 * 异常码
	 **/
	public $error_code;
	
	/** 
	 * 错误描述
	 **/
	public $error_msg;	
}
?>
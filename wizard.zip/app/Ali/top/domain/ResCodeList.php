<?php

/**
 * 仓列表
 * @author auto create
 */
class ResCodeList
{
	
	/** 
	 * code
	 **/
	public $code;
	
	/** 
	 * name
	 **/
	public $name;	
}
?>
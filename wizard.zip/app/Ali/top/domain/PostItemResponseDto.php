<?php

/**
 * result
 * @author auto create
 */
class PostItemResponseDto
{
	
	/** 
	 * productId
	 **/
	public $product_id;	
}
?>
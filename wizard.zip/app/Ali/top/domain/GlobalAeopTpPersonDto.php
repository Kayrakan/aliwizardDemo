<?php

/**
 * buyer info
 * @author auto create
 */
class GlobalAeopTpPersonDto
{
	
	/** 
	 * country/region
	 **/
	public $country;
	
	/** 
	 * first name
	 **/
	public $first_name;
	
	/** 
	 * last name
	 **/
	public $last_name;
	
	/** 
	 * login ID
	 **/
	public $login_id;	
}
?>
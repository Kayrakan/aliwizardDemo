<?php

/**
 * result
 * @author auto create
 */
class AeopOfferBundleDeleteResult
{
	
	/** 
	 * 错误码
	 **/
	public $error_code;
	
	/** 
	 * 错误消息
	 **/
	public $error_message;
	
	/** 
	 * 返回时间
	 **/
	public $time_stamp;	
}
?>
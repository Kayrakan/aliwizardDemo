<?php

/**
 * result
 * @author auto create
 */
class AeopOfferBundleFindResult
{
	
	/** 
	 * 搭配ID
	 **/
	public $bundle_id;
	
	/** 
	 * 错误码
	 **/
	public $error_code;
	
	/** 
	 * 错误消息
	 **/
	public $error_message;
	
	/** 
	 * 搭配主商品
	 **/
	public $main_item;
	
	/** 
	 * 搭配排列顺序
	 **/
	public $order;
	
	/** 
	 * 搭配商品列表
	 **/
	public $sub_item_list;	
}
?>
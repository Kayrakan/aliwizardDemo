<?php

/**
 * 商家信息参数
 * @author auto create
 */
class OpenSellerInfoParam
{
	
	/** 
	 * 跨店铺组包时的店铺分组ID
	 **/
	public $top_user_key;	
}
?>
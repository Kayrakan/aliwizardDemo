<?php

/**
 * 买家信息
 * @author auto create
 */
class AeopTpPersonDto
{
	
	/** 
	 * 国家/地区
	 **/
	public $country;
	
	/** 
	 * first name
	 **/
	public $first_name;
	
	/** 
	 * last name
	 **/
	public $last_name;
	
	/** 
	 * 登录id
	 **/
	public $login_id;	
}
?>
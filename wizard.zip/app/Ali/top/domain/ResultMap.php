<?php

/**
 * 枚举
 * @author auto create
 */
class ResultMap
{
	
	/** 
	 * delivery国家
	 **/
	public $country_of_delivery_list;
	
	/** 
	 * destination国家
	 **/
	public $country_of_destination_list;
	
	/** 
	 * 头程单状态
	 **/
	public $logistics_order_status_list;	
}
?>
<?php

/**
 * Multimedia information
 * @author auto create
 */
class GlobalAeopAeMultimedia
{
	
	/** 
	 * video information
	 **/
	public $aeop_a_e_videos;	
}
?>
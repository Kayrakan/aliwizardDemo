<?php

/**
 * 可用物流服务列表
 * @author auto create
 */
class LogisticService
{
	
	/** 
	 * 物流服务Code
	 **/
	public $code;
	
	/** 
	 * 物流服务名称
	 **/
	public $name;	
}
?>
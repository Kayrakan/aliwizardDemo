<?php

/**
 * result
 * @author auto create
 */
class MerchantServiceResponse
{
	
	/** 
	 * 错误码
	 **/
	public $error_code;
	
	/** 
	 * 错误信息
	 **/
	public $error_info;
	
	/** 
	 * mode
	 **/
	public $mode;
	
	/** 
	 * 是否成功
	 **/
	public $success;	
}
?>
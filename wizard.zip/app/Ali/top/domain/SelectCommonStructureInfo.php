<?php

/**
 * 头程单状态
 * @author auto create
 */
class SelectCommonStructureInfo
{
	
	/** 
	 * code
	 **/
	public $code;
	
	/** 
	 * name
	 **/
	public $name;	
}
?>
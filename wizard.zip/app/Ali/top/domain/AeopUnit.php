<?php

/**
 * 发布属性单位
 * @author auto create
 */
class AeopUnit
{
	
	/** 
	 * 和标准属性对换比率
	 **/
	public $rate;
	
	/** 
	 * 单位名称
	 **/
	public $unit_name;	
}
?>
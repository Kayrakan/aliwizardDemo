<?php

/**
 * 营销图列表
 * @author auto create
 */
class MarketImage
{
	
	/** 
	 * 1：代表长图，大小为750*1000;	2：代表方图，大小为800*800
	 **/
	public $image_type;
	
	/** 
	 * 营销图片URL
	 **/
	public $url;	
}
?>
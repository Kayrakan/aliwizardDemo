<?php

/**
 * 交易单参数
 * @author auto create
 */
class OpenTradeOrderParam
{
	
	/** 
	 * 交易单ID
	 **/
	public $trade_order_id;	
}
?>
<?php

/**
 * 卖家资料
 * @author auto create
 */
class MerchantProfile
{
	
	/** 
	 * 卖家所属国家
	 **/
	public $country;
	
	/** 
	 * 卖家可以使用的报价币种
	 **/
	public $quotation_currency;	
}
?>
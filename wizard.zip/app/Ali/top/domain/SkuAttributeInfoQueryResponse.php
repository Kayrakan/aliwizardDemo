<?php

/**
 * result
 * @author auto create
 */
class SkuAttributeInfoQueryResponse
{
	
	/** 
	 * common attributes under a specific category
	 **/
	public $supporting_common_attribute_list;
	
	/** 
	 * supported sku attribute lis
	 **/
	public $supporting_sku_attribute_list;	
}
?>
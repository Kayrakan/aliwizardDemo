<?php

/**
 * discount detail list for each child order
 * @author auto create
 */
class GlobalAeopTpSaleDiscountInfo
{
	
	/** 
	 * discount detail
	 **/
	public $discount_detail;
	
	/** 
	 * promotion ID
	 **/
	public $promotion_id;
	
	/** 
	 * Promotion owner, can be Seller, Platform or Mix.
	 **/
	public $promotion_owner;
	
	/** 
	 * promotion type
	 **/
	public $promotion_type;	
}
?>
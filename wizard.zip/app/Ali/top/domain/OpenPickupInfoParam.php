<?php

/**
 * 揽收信息参数
 * @author auto create
 */
class OpenPickupInfoParam
{
	
	/** 
	 * 卖家后台地址id,用来获取卖家详细地址信息，传入值为Long型；
	 **/
	public $seller_address_id;	
}
?>
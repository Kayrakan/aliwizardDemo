<?php

/**
 * 12345
 * @author auto create
 */
class Refundselleraddresslist
{
	
	/** 
	 * addressId
	 **/
	public $address_id;
	
	/** 
	 * city
	 **/
	public $city;
	
	/** 
	 * country
	 **/
	public $country;
	
	/** 
	 * county
	 **/
	public $county;
	
	/** 
	 * email
	 **/
	public $email;
	
	/** 
	 * fax
	 **/
	public $fax;
	
	/** 
	 * isDefault
	 **/
	public $is_default;
	
	/** 
	 * language
	 **/
	public $language;
	
	/** 
	 * memberType
	 **/
	public $member_type;
	
	/** 
	 * mobile
	 **/
	public $mobile;
	
	/** 
	 * name
	 **/
	public $name;
	
	/** 
	 * NeedToUpdate
	 **/
	public $need_to_update;
	
	/** 
	 * phone
	 **/
	public $phone;
	
	/** 
	 * postcode
	 **/
	public $postcode;
	
	/** 
	 * province
	 **/
	public $province;
	
	/** 
	 * street
	 **/
	public $street;
	
	/** 
	 * streetAddress
	 **/
	public $street_address;
	
	/** 
	 * trademanageId
	 **/
	public $trademanage_id;	
}
?>
<?php

/**
 * 用户信息
 * @author auto create
 */
class UserInfoDto
{
	
	/** 
	 * 每个商家在ISV系统的唯一标识，一般为商家ISV账号的id
	 **/
	public $top_user_key;	
}
?>
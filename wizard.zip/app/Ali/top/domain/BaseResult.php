<?php

/**
 * result
 * @author auto create
 */
class BaseResult
{
	
	/** 
	 * data
	 **/
	public $data;
	
	/** 
	 * error code
	 **/
	public $error_code;
	
	/** 
	 * error message
	 **/
	public $error_message;
	
	/** 
	 * time stamp
	 **/
	public $time_stamp;	
}
?>
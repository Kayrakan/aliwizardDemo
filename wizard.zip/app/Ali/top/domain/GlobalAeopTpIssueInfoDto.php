<?php

/**
 * child issue info
 * @author auto create
 */
class GlobalAeopTpIssueInfoDto
{
	
	/** 
	 * issue model
	 **/
	public $issue_model;
	
	/** 
	 * issue status: processing, canceled_issue, finish
	 **/
	public $issue_status;
	
	/** 
	 * issue creation time
	 **/
	public $issue_time;	
}
?>
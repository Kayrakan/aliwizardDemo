<?php

/**
 * filePath
 * @author auto create
 */
class FilePath
{
	
	/** 
	 * lPath
	 **/
	public $l_path;
	
	/** 
	 * mPath
	 **/
	public $m_path;
	
	/** 
	 * sPath
	 **/
	public $s_path;	
}
?>
<?php

/**
 * result
 * @author auto create
 */
class AeopCategoryForecastResultDto
{
	
	/** 
	 * 预测结果
	 **/
	public $category_suitability_list;
	
	/** 
	 * 错误代码
	 **/
	public $error_code;
	
	/** 
	 * 错误信息
	 **/
	public $error_message;
	
	/** 
	 * 调用结果
	 **/
	public $success;
	
	/** 
	 * 时间戳
	 **/
	public $time_stamp;	
}
?>